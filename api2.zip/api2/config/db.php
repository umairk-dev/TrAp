<?php
return [
  'class' => 'yii\db\Connection',
              'dsn' => 'mysql:host=',
              'username' => '',
              'password' => '',
              'charset' => 'utf8',
];
