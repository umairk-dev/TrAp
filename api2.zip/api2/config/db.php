<?php
return [
  'class' => 'yii\db\Connection',
              'dsn' => 'mysql:host=130.56.253.211:3306;dbname=trap',
              'username' => 'wfoxd',
              'password' => '123qwe123',
              'charset' => 'utf8',
];
