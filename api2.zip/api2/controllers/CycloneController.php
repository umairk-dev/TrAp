<?php
namespace app\controllers;

use yii\rest\ActiveController;
use yii\data\Pagination;
use app\models\Cyclone;
use app\models\CycloneTrack;
use app\models\Version;
use app\models\El;
use Yii;

class CycloneController extends ActiveController
{
    public $modelClass = 'app\models\Cyclone';

    /**
     * Default response format
     * either 'json' or 'xml'
     */
    private $format = 'json';

    // index.php?r=cyclone/version
    public function actionVersion()
    {
        $ver = Version::find()->one();

        return $ver;
    }

    // index.php?r=cyclone/el&year=&gap=
    public function actionEl()
    {
        $request = Yii::$app->request;
        $year = $request->get('year');
        $gap = $request->get('gap');
        $query = El::find();
        $el = $query->where(['and', "year=:year", 'gap=:gap'])->addParams([':year' => $year, ':gap' => $gap])->one();
        return $el;
    }

    // index.php?r=cyclone/cyclone&id=
    public function actionCyclone()
    {
        $request = Yii::$app->request;
        $cyclone = Cyclone::findOne($request->get('id'));
        $tracks = CycloneTrack::find()
          ->where(['cyclone' => $cyclone->id])
          ->all();

        return [
            'cyclone' => $cyclone,
            'tracks' => $tracks,
        ];
    }

    // index.php?r=cyclone/searchbyname&key=
    public function actionSearchbyname()
    {
        $request = Yii::$app->request;
        $key = $request->post('key');
        if($key == null) $key = $request->get('key');

        $query = Cyclone::find();
        if($request->get('source')){
          $cyclones = $query->where(['source' => intval($request->get('source'))])
                            ->andWhere(['like', 'name', $key])
                            ->all();
        }else{
          $cyclones =
            $query->where(['like', 'name', $key])
            ->all();
        }

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbyyear&key=
    public function actionSearchbyyear()
    {
        $request = Yii::$app->request;
        $key = $request->post('key');
        if($key == null) $key = $request->get('key');

        $query = Cyclone::find();

        if($request->get('source')){
          $cyclones = $query->where(['source' => intval($request->get('source'))])
                            ->andWhere(['year'=>$key])
                            ->all();
        }else{
          $cyclones =
            $query->where(['year'=>$key])
            ->all();
        }

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbyyears&yearfrom=&yearto=
    public function actionSearchbyyears()
    {
        $request = Yii::$app->request;
        $yearfrom = $request->get('yearfrom');
        $yearto = $request->get('yearto');
        $source = $request->get('source');

        $query = Cyclone::find();
        if($request->get('source')){
          $cyclones = $query->where(['and', 'year>=:yearfrom', 'year<=:yearto', 'source=:source' ])
                            ->addParams([':yearfrom' => $yearfrom])
                            ->addParams([':yearto' => $yearto])
                            ->addParams([':source' => intval($source)])
                            ->all();
        }else{
          $cyclones =
            $query
            ->where(['and', 'year>=:yearfrom', 'year<=:yearto'])
            ->addParams([':yearfrom' => $yearfrom])
            ->addParams([':yearto' => $yearto])
            ->all();
        }


        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbywind&windfrom=&windto=
    public function actionSearchbywind()
    {
        $request = Yii::$app->request;
        $windfrom = $request->get('windfrom');
        $windto = $request->get('windto');
        $source = $request->get('source');

        $query = CycloneTrack::find();

        if($request->get('source')){
          $cyclonesResult = $query
          ->where(['and', 'wind>=:windfrom', 'wind<=:windto', 'source=:source'])
          ->addParams([':windfrom' => $windfrom])
          ->addParams([':windto' => $windto])
          ->addParams([':source' =>intval($source)])
          ->groupBy(['cyclone'])
          ->all();
        }else{
          $cyclonesResult =
              $query
              ->where(['and', 'wind>=:windfrom', 'wind<=:windto'])
              ->addParams([':windfrom' => $windfrom])
              ->addParams([':windto' => $windto])
              ->groupBy(['cyclone'])
              ->all();
          }

        $cyclones = array();
        foreach ($cyclonesResult as $cyc) {
          $cyclone = Cyclone::findOne($cyc->cyclone);
          $cyclones[] = $cyclone;
        }

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbypressure&pressurefrom=&pressureto=
    public function actionSearchbypressure()
    {
        $request = Yii::$app->request;
        $pressurefrom = $request->get('pressurefrom');
        $pressureto = $request->get('pressureto');
        $source = $request->get('source');

        $query = CycloneTrack::find();
        if($request->get('source')){
          $cyclonesResult = $query
          ->where(['and', 'pressure>=:pressurefrom', 'pressure<=:pressureto','source=:source'])
          ->addParams([':pressurefrom' => $pressurefrom])
          ->addParams([':pressureto' => $pressureto])
          ->addParams([':source' => intval($source)])
          ->groupBy(['cyclone'])
          ->all();
        }else{
          $cyclonesResult =
            $query
            ->where(['and', 'pressure>=:pressurefrom', 'pressure<=:pressureto'])
            ->addParams([':pressurefrom' => $pressurefrom])
            ->addParams([':pressureto' => $pressureto])
            ->groupBy(['cyclone'])
            ->all();
          }

        $cyclones = array();
        foreach ($cyclonesResult as $cyc) {
          $cyclone = Cyclone::findOne($cyc->cyclone);
          $cyclones[] = $cyclone;
        }

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbyregion&latfrom=&lntfrom=&latto=&lntto=
    public function actionSearchbyregion()
    {
        $request = Yii::$app->request;

        $latfrom = $request->get('latfrom');
        $lantfrom = $request->get('lntfrom');

        $latto = $request->get('latto');
        $lntto = $request->get('lntto');
        $source = $request->get('source');

        $sql = "SELECT * FROM cyclone_track WHERE 1=1";
        if($request->get('source')){
          $sql .= " and source=".$request->get('source');
        }
        if($latto < 0){
            $sql .= " and latitude<=".$latfrom;
            $sql .= " and latitude>=".$latto;
        }else{
          $sql .= " and latitude>=".$latfrom;
          $sql .= " and latitude<=".$latto;
        }
        if($lntto < 0){
            $sql .= " and longitude<=".$lantfrom;
            $sql .= " and longitude>=".$lntto;
        }else{
            $sql .= " and longitude>=".$lantfrom;
            $sql .= " and longitude<=".$lntto;
        }

        $cyclonesResult =  CycloneTrack::findBySql($sql)->all();
        $cyclones = array();
        foreach ($cyclonesResult as $cyc) {
          $cyclone = Cyclone::findOne($cyc->cyclone);
          $cyclones[] = $cyclone;
        }

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchall&yearfrom=&yearto=&windfrom=&windto=&pressurefrom=&pressureto=&latfrom=&lntfrom=&latto=&lntto=
    public function actionSearchall()
    {
        $request = Yii::$app->request;

        $latfrom = $request->get('latfrom');
        $lantfrom = $request->get('lntfrom');

        $latto = $request->get('latto');
        $lntto = $request->get('lntto');

        $pressurefrom = $request->get('pressurefrom');
        $pressureto = $request->get('pressureto');

        $windfrom = $request->get('windfrom');
        $windto = $request->get('windto');

        $yearfrom = $request->get('yearfrom');
        $yearto = $request->get('yearto');

        $type = $request->get('type');

        $source = $request->get('source');
        $query = CycloneTrack::find();


        $sql = "SELECT * FROM cyclone_track WHERE 1=1";

        if($request->get('source')){
          $sql .= " and source=".$request->get('source');
        }

        if($yearfrom != '' && $yearto != ''){
          $sql .= " and year>='".$yearfrom."' and year<='".$yearto."'";
        }

        if($latfrom != '' && $lantfrom != '' && $latto != '' && $lntto != ''){
          if($latto < 0){
              $sql .= " and latitude<=".$latfrom;
              $sql .= " and latitude>=".$latto;
          }else{
            $sql .= " and latitude>=".$latfrom;
            $sql .= " and latitude<=".$latto;
          }
          if($lntto < 0){
              $sql .= " and longitude<=".$lantfrom;
              $sql .= " and longitude>=".$lntto;
          }else{
              $sql .= " and longitude>=".$lantfrom;
              $sql .= " and longitude<=".$lntto;
          }
        }

        if($windfrom != '' && $windto != ''){
          $sql .= " and wind>=".$windfrom." and wind<=".$windto;
        }

        if($pressurefrom != '' && $pressureto != ''){
          $sql .= " and pressure>=".$pressurefrom." and pressure<=".$pressureto;
        }

        if($type != ''){
          $sql .= " and ctype='".$type."'";
        }

        $cyclonesResult =  CycloneTrack::findBySql($sql)->all();

        $cyclones = array();
        foreach ($cyclonesResult as $cyc) {$cyclone = Cyclone::findOne($cyc->cyclone);
          $cyclones[] = $cyclone;
        }

        return $this->cycloneData($cyclones);
        $query = CycloneTrack::find();
    }


    private function cycloneData($cyclones){
        $results = array();

        foreach ($cyclones as $cyc) {
            $tacks =  CycloneTrack::find()
                      ->asArray()
                      ->where(['cyclone' => $cyc->id])
                      ->all();

            $results[] = ['cyclone'=>$cyc, 'tracks'=>$tacks];
        }

        return [
            'cyclones' => $results,
            'total' => count($results),
        ];
    }
}
