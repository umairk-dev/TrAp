<?php
namespace app\controllers;

use yii\rest\ActiveController;
use yii\data\Pagination;
use app\models\Cyclone;
use app\models\CycloneTrack;
use Yii;

class CycloneController extends ActiveController
{
    public $modelClass = 'app\models\Cyclone';

    /**
     * Default response format
     * either 'json' or 'xml'
     */
    private $format = 'json';

    // index.php?r=cyclone/cyclones
    public function actionCyclones()
    {
        $query = Cyclone::find();
        $cyclones = $query->all();

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/cyclone&id=
    public function actionCyclone()
    {
        $request = Yii::$app->request;
        $cyclone = Cyclone::findOne($request->get('id'));
        $tracks = CycloneTrack::find()
          ->where(['cyclone' => $cyclone->id])
          ->all();

        return [
            'cyclone' => $cyclone,
            'tracks' => $tracks,
        ];
    }

    // index.php?r=cyclone/searchbyname&key=
    public function actionSearchbyname()
    {
        $request = Yii::$app->request;
        $key = $request->post('key');
        if($key == null) $key = $request->get('key');

        $query = Cyclone::find();
        $cyclones =
            $query->where(['like', 'name', $key])
            ->all();

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbyyear&key=
    public function actionSearchbyyear()
    {
        $request = Yii::$app->request;
        $key = $request->post('key');
        if($key == null) $key = $request->get('key');

        $query = Cyclone::find();

        $cyclones =
            $query->where(['year'=>$key])
            ->all();

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbyyears&yearfrom=&yearto=
    public function actionSearchbyyears()
    {
        $request = Yii::$app->request;
        $yearfrom = $request->get('yearfrom');
        $yearto = $request->get('yearto');

        $query = Cyclone::find();

        $cyclones =
            $query
            ->where(['and', 'year>=:yearfrom', 'year<=:yearto'])
            ->addParams([':yearfrom' => $yearfrom])
            ->addParams([':yearto' => $yearto])
            ->all();


        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbywind&windfrom=&windto=
    public function actionSearchbywind()
    {
        $request = Yii::$app->request;
        $windfrom = $request->get('windfrom');
        $windto = $request->get('windto');

        $query = CycloneTrack::find();

        $cyclonesResult =
            $query
            ->where(['and', 'wind>=:windfrom', 'wind<=:windto'])
            ->addParams([':windfrom' => $windfrom])
            ->addParams([':windto' => $windto])
            ->groupBy(['cyclone'])
            ->all();

        $cyclones = array();
        foreach ($cyclonesResult as $cyc) {
          $cyclone = Cyclone::findOne($cyc->cyclone);
          $cyclones[] = $cyclone;
        }

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbypressure&pressurefrom=&pressureto=
    public function actionSearchbypressure()
    {
        $request = Yii::$app->request;
        $pressurefrom = $request->get('pressurefrom');
        $pressureto = $request->get('pressureto');

        $query = CycloneTrack::find();

        $cyclonesResult =
            $query
            ->where(['and', 'pressure>=:pressurefrom', 'pressure<=:pressureto'])
            ->addParams([':pressurefrom' => $pressurefrom])
            ->addParams([':pressureto' => $pressureto])
            ->groupBy(['cyclone'])
            ->all();

        $cyclones = array();
        foreach ($cyclonesResult as $cyc) {
          $cyclone = Cyclone::findOne($cyc->cyclone);
          $cyclones[] = $cyclone;
        }

        return $this->cycloneData($cyclones);
    }

    // index.php?r=cyclone/searchbyregion&latfrom=&lntfrom=&latto=&lntto=
    public function actionSearchbyregion()
    {
        $request = Yii::$app->request;

        $latfrom = $request->get('latfrom');
        $lantfrom = $request->get('lntfrom');

        $latto = $request->get('latto');
        $lntto = $request->get('lntto');

        $query = CycloneTrack::find();

        $cyclonesResult =
            $query
            ->where(['and','latitude<=:latfrom', 'latitude>=:latto', 'longitude>=:lantfrom', 'longitude<=:lantto'])
            ->addParams([':latfrom' => $latfrom])
            ->addParams([':latto' => $latto])
            ->addParams([':lantfrom' => $lantfrom])
            ->addParams([':lantto' => $lntto])
            ->groupBy(['cyclone'])
            ->all();

        $cyclones = array();
        foreach ($cyclonesResult as $cyc) {
          $cyclone = Cyclone::findOne($cyc->cyclone);
          $cyclones[] = $cyclone;
        }

        return $this->cycloneData($cyclones);
    }


    private function cycloneData($cyclones){
        $results = array();

        foreach ($cyclones as $cyc) {
            $tacks =  CycloneTrack::find()
                      ->asArray()
                      ->where(['cyclone' => $cyc->id])
                      ->all();

            $results[] = ['cyclone'=>$cyc, 'tracks'=>$tacks];
        }

        return [
            'cyclones' => $results,
            'total' => count($results),
        ];
    }
}
