<?php

namespace app\models;

use yii\db\ActiveRecord;
use app\models\CycloneTrack;

class Cyclone extends ActiveRecord
{

  public function rules()
  {
      return [
          // the name, email, subject and body attributes are required
          [['name', 'year', 'serial_num', 'track_date', 'nature'], 'required'],
          [['year'], 'number'],
          [['track_date'], 'date', 'format'=>'yyyy-MM-dd HH:mm:ss'],
          [['name', 'serial_num', 'nature', 'name'], 'string'],
      ];
  }
}
