<?php

namespace app\models;

use yii\db\ActiveRecord;
use app\models\CycloneTrack;

class Version extends ActiveRecord
{

}
