<?php

namespace app\models;

use yii\db\ActiveRecord;

class CycloneTrack extends ActiveRecord
{
  public function rules()
  {
      return [
          // the name, email, subject and body attributes are required
          [['basin', 'sub_basin', 'latitude', 'longitude', 'wind', 'pressure'], 'required'],
          [['latitude', 'longitude', 'wind', 'pressure'], 'number'],
          [['basin', 'sub_basin'], 'string'],
      ];
  }
}
