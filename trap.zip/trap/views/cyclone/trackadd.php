<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

$this->title = "Cyclone :: Track Creating";
?>

<h1>Track Editing</h1>

<?php $form = ActiveForm::begin(['action' =>['cyclone/tracksave'], 'method' => 'post',]); ?>
<?= $form->field($cycloneTrack, 'basin') ?>
<?= $form->field($cycloneTrack, 'sub_basin') ?>
<?= $form->field($cycloneTrack, 'latitude') ?>
<?= $form->field($cycloneTrack, 'longitude') ?>
<?= $form->field($cycloneTrack, 'wind') ?>
<?= $form->field($cycloneTrack, 'pressure') ?>
<input name="cyclone_id" id="cyclone_id" type="hidden" value="<?= $cycloneId?>" />
<div class="form-group">
        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
    </div>
<?php ActiveForm::end(); ?>
