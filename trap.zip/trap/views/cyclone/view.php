<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
use yii\helpers\Url;

$this->title = "Cyclone :: Detail";
?>

<h1><?= $cyclone->name ?> <small><a href="<?= Url::to(['cyclone/edit', 'id' => $cyclone->id])?>"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></small></a></h1>
<table class="table table-bordered">
   <tbody>

     <tr>
       <td class="info">Year</td>
       <td><?= $cyclone->year ?></td>
       <td class="info">Date</td>
       <td><?= $cyclone->track_date ?></td>
     </tr>
     <tr>
       <td class="info">Serial Number</td>
       <td><?= $cyclone->serial_num ?></td>
       <td class="info">Nature</td>
       <td><?= $cyclone->nature ?></td>
     </tr>
   </tbody>
</table>
    <style>
      #map {
        height: 500px;
      }
    </style>
    <div id="map"></div>
    <script>
      var map;


      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -25.112273, lng: 134.565147},
          zoom: 4
        });

        var cyclonesCoordinates = [
            <?php foreach ($tracks as $index=>$track): ?>
              {lat: <?= $track->latitude ?>, lng: <?= $track->longitude ?>}
              <?php if(count($tracks)-1 != $index): ?> , <?php endif; ?>
            <?php endforeach; ?>
        ];

        var cyclonePath = new google.maps.Polyline({
          path: cyclonesCoordinates,
          geodesic: true,
          strokeColor: '#FF0000',
          strokeOpacity: 1.0,
          strokeWeight: 2
        });

        cyclonePath.setMap(map);
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA6lvhmJsYI3C6UWuKzbyvdcaNm9D_bUqo&callback=initMap"
    async defer></script>
