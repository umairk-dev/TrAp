<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
use yii\helpers\Url;

$this->title = "Cyclone :: List";
?>

<h1>Cyclones (<?=$pagination->totalCount?>)</h1>
<div class="row">
  <div class="col-md-8">
  <form action="<?= Url::to(['cyclone/search']) ?>" method="post" class="form-inline">
          <input type="hidden" name="_csrf" value="<?=Yii::$app->request->getCsrfToken()?>" />
          <div class="form-group">
            <input type="text" class="form-control" name="key" placeholder="Cyclone..." value="<?=$key?>">
          </div>
          <button type="submit" class="btn btn-default">Search</button>
  </form>
  <select class="form-control" id="year" name="year" onchange="changeFunc();">
    <?php foreach ($years as $year): ?>
      <option value="<?= Url::to(['cyclone/yearlist', 'year' => $year->year]) ?>"><?=$year->year?></option>
    <?php endforeach; ?>
  </select>
  </div>
</div>
<p class="text-right">
  <a href="<?= Url::to(['cyclone/cycloneadd'])?>"><span class="glyphicon glyphicon-plus-sign" style="font-size:25px;" aria-hidden="true"></span></a>
</p>
<table class="table table-striped">
   <thead>
     <tr>
       <th>Cyclone Name</th>
       <th>Year</th>
       <th>Date</th>
       <th>Serial Number</th>
       <th>Nature</th>
       <th></th>
      </tr>
   </thead>
   <tbody>
     <?php foreach ($cyclones as $cyclone): ?>
     <tr>
       <td><a href="<?= Url::to(['cyclone/view', 'id' => $cyclone->id]) ?>"><?= Html::encode("{$cyclone->name}") ?></a></td>
       <td><?= $cyclone->year ?></td>
       <td><?= $cyclone->track_date ?></td>
       <td><?= $cyclone->serial_num ?></td>
       <td><?= $cyclone->nature ?></td>
       <td><a href="<?= Url::to(['cyclone/cyclonedel', 'id' => $cyclone->id]) ?>" onclick="return confirm('Are you sure you want to delete this item?');"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a></td>
     </tr>
     <?php endforeach; ?>
   </tbody>
  </table>
<?= LinkPager::widget(['pagination' => $pagination]) ?>
<script type="text/javascript">

   function changeFunc() {
    var selectBox = document.getElementById("year");
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;
    window.location = selectedValue;
   }

  </script>
