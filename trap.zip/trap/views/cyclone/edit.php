<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

$this->title = "Cyclone :: Detail Editing";
?>

<h1><?= $cyclone->name ?> Editing</h1>

<?php $form = ActiveForm::begin(['action' =>['cyclone/update'], 'method' => 'post',]); ?>
<?= $form->field($cyclone, 'name') ?>
<?= $form->field($cyclone, 'year') ?>
<?= $form->field($cyclone, 'serial_num') ?>
<?= $form->field($cyclone, 'track_date') ?>
<?= $form->field($cyclone, 'nature') ?>
<input name="id" id="id" type="hidden" value="<?= $cyclone->id?>" />
<div class="form-group">
        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
    </div>
<?php ActiveForm::end(); ?>


<p class="text-right">
  <a href="<?= Url::to(['cyclone/trackadd', 'cycloneId' => $cyclone->id])?>"><span class="glyphicon glyphicon-plus-sign" style="font-size:25px;" aria-hidden="true"></span></a>
</p>
<table class="table table-striped">
   <thead>
     <tr>
       <th>Basin</th>
       <th>Sub Basin</th>
       <th>Latitude</th>
       <th>Longitude</th>
       <th>Wind</th>
       <th>Pressure</th>
      </tr>
   </thead>
   <tbody>
     <?php foreach ($tracks as $track): ?>
     <tr>
       <td><?= $track->basin ?></td>
       <td><?= $track->sub_basin ?></td>
       <td><?= $track->latitude ?></td>
       <td><?= $track->longitude ?></td>
       <td><?= $track->wind ?></td>
       <td><?= $track->pressure ?></td>
       <td>
         <a href="<?= Url::to(['cyclone/trackedit', 'id' => $track->id, 'cycloneId' => $cyclone->id]) ?>"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <a href="<?= Url::to(['cyclone/trackdel', 'id' => $track->id, 'cycloneId' => $cyclone->id]) ?>" onclick="return confirm('Are you sure you want to delete this item?');"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a>
       </td>
     </tr>
     <?php endforeach; ?>
   </tbody>
 </table>
