<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

$this->title = "Cyclone :: Track Creating";
?>

<h1>Track Editing</h1>

<?php $form = ActiveForm::begin(['action' =>['cyclone/cyclonesave'], 'method' => 'post',]); ?>
<?= $form->field($cyclone, 'name') ?>
<?= $form->field($cyclone, 'year') ?>
<?= $form->field($cyclone, 'serial_num') ?>
<?= $form->field($cyclone, 'track_date') ?>
<?= $form->field($cyclone, 'nature') ?>
<input name="id" id="id" type="hidden" value="<?= $cyclone->id?>" />
<div class="form-group">
        <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
    </div>
<?php ActiveForm::end(); ?>
