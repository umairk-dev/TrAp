<?php

namespace app\controllers;
use yii\helpers\Url;
use yii\web\Controller;
use yii\data\Pagination;
use app\models\Cyclone;
use app\models\CycloneTrack;
use Yii;

class CycloneController extends Controller
{
    private function years(){
      $years = Cyclone::find()->select(['year'])
      ->orderBy(['year' => SORT_DESC,])
      ->groupBy(['year'])
      ->all();

      return $years;
    }

    public function actionIndex()
    {
        $query = Cyclone::find();

        $pagination = new Pagination([
            'defaultPageSize' => 20,
            'totalCount' => $query->count(),
        ]);

        $cyclones = $query->orderBy(['year' => SORT_DESC,])
            ->offset($pagination->offset)
            ->limit($pagination->limit)
            ->all();

        return $this->render('index', [
            'cyclones' => $cyclones,
            'pagination' => $pagination,
            'key' => '',
            'years' => $this->years(),
        ]);
    }

    public function actionView()
    {
        $request = Yii::$app->request;
        $cyclone = Cyclone::findOne($request->get('id'));
        $tracks = CycloneTrack::find()
          ->where(['cyclone' => $cyclone->id])
          ->all();

        return $this->render('view', [
            'cyclone' => $cyclone,
            'tracks' => $tracks,
        ]);
    }

    public function actionYearlist()
    {
        $request = Yii::$app->request;
        $year = $request->get('year');

        $pagination = new Pagination([
                'defaultPageSize' => 20,
                'params' => array_merge($_GET, ['year' => $year]),
                'totalCount' => Cyclone::find()->where(['year'=>$year])->count(),
        ]);

        $cyclones = Cyclone::find()->where(["year"=>$year])->all();

        return $this->render('index', [
            'cyclones' => $cyclones,
            'years' => $this->years(),
            'pagination' => $pagination,
            'key'=>'',
        ]);
    }

    public function actionUpdate()
    {
        $request = Yii::$app->request;
        $model = Cyclone::findOne($request->post('id'));

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $model->save();
            return $this->redirect(Url::to(['/cyclone/view', 'id' => $model->id]), 302);
        } else {
            $tracks = CycloneTrack::find()
            ->where(['cyclone' => $model->id])
            ->all();

            return $this->render('edit', [
                'cyclone' => $model,
                'tracks' => $tracks,
            ]);
        }
    }

    public function actionEdit()
    {
      $request = Yii::$app->request;
      $cyclone = Cyclone::findOne($request->get('id'));

      $tracks = CycloneTrack::find()
        ->where(['cyclone' => $cyclone->id])
        ->all();

      return $this->render('edit', [
          'cyclone' => $cyclone,
          'tracks' => $tracks,
      ]);
    }

    public function actionTrackadd()
    {
      $request = Yii::$app->request;
      $cycloneTrack = new CycloneTrack();

      return $this->render('trackadd', [
          'cycloneTrack' => $cycloneTrack,
          'cycloneId' => $request->get('cycloneId'),
      ]);
    }

    public function actionTracksave()
    {
        $request = Yii::$app->request;
        $model = new CycloneTrack();
        $cycloneId = $request->post('cyclone_id');

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $model->cyclone = $cycloneId;
            $model->save();
            return $this->redirect(Url::to(['/cyclone/edit', 'id' => $cycloneId]), 302);
        } else {
            return $this->render('edit', [
                'cycloneTrack' => $model,
                'cycloneId' => $request->get('cycloneId'),
            ]);
        }
    }

    public function actionTrackedit()
    {
      $request = Yii::$app->request;
      $cycloneTrack = CycloneTrack::findOne($request->get('id'));

      return $this->render('trackedit', [
          'cycloneTrack' => $cycloneTrack,
          'cycloneId' => $request->get('cycloneId'),
      ]);
    }

    public function actionTrackdel()
    {
      $request = Yii::$app->request;
      $cycloneTrack = CycloneTrack::findOne($request->get('id'));
      $cycloneTrack->delete();
      return $this->redirect(Url::to(['/cyclone/edit', 'id' => $request->get('cycloneId')]), 302);
    }

    public function actionTrackupdate()
    {
        $request = Yii::$app->request;
        $model = CycloneTrack::findOne($request->post('id'));
        $cycloneId = $request->post('cyclone_id');

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $model->save();
            return $this->redirect(Url::to(['/cyclone/edit', 'id' => $cycloneId]), 302);
        } else {
            return $this->render('edit', [
                'cycloneTrack' => $model,
                'cycloneId' => $request->get('cycloneId'),
            ]);
        }
    }

    public function actionCyclonedel()
    {
      $request = Yii::$app->request;
      $cyclone = Cyclone::findOne($request->get('id'));
      $cyclone->delete();

      return $this->redirect(Url::to(['/cyclone/index']), 302);
    }

    public function actionCycloneadd()
    {
      $request = Yii::$app->request;
      $cyclone = new Cyclone();

      return $this->render('cycloneadd', [
          'cyclone' => $cyclone,
      ]);
    }

    public function actionCyclonesave()
    {
        $request = Yii::$app->request;
        $model = new Cyclone();

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $model->save();
            return $this->redirect(Url::to(['/cyclone/view', 'id' => $model->id]), 302);
        } else {
            return $this->render('cycloneadd', [
                'cyclone' => $model,
            ]);
        }
    }

    public function actionSearch()
    {
      $request = Yii::$app->request;
      $key = $request->post('key');
      if($key == null) $key = $request->get('key');

      $query = Cyclone::find();

      $pagination = new Pagination([
              'defaultPageSize' => 20,
              'params' => array_merge($_GET, ['key' => $key]),
              'totalCount' => $query->where(['like', 'name', $key])->count(),
      ]);

      $cyclones =
          $query->where(['like', 'name', $key])
          ->orderBy(['year' => SORT_DESC,])
          ->offset($pagination->offset)
          ->limit($pagination->limit)
          ->all();



      return $this->render('index', [
          'cyclones' => $cyclones,
          'pagination' => $pagination,
          'key' => $key,
          'years' => $this->years(),
      ]);
    }
}
